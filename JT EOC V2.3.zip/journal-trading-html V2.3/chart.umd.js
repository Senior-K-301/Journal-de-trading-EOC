
// Chart.js placeholder
window.Chart=function(c,a){console.warn("Chart.js non chargé. Ce fichier est un placeholder.");return{}}
